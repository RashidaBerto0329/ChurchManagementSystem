
<?php $__env->startSection('content'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const godparentsContainer = document.getElementById("godparents-container");
        const addGodparentBtn = document.getElementById("add-godparent-btn");

        // Function to create a new godparent entry
        function createGodparentEntry() {
            const godparentEntry = document.createElement("div");
            godparentEntry.classList.add("godparent-entry");

            godparentEntry.innerHTML = `
                <div class="row">
                  <!-- First Name -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="godparentFirstName">First Name</label>
                      <input type="text" class="form-control" name="godparentFirstName[]" placeholder="Enter First Name" />
                    </div>
                  </div>

                  <!-- Middle Name -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="godparentMiddleName">Middle Name</label>
                      <input type="text" class="form-control" name="godparentMiddleName[]" placeholder="Enter Middle Name" />
                    </div>
                  </div>

                  <!-- Last Name -->
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="godparentLastName">Last Name</label>
                      <input type="text" class="form-control" name="godparentLastName[]" placeholder="Enter Last Name" />
                    </div>
                  </div>

                  <!-- Purok No. -->
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="godparentPurok">Purok No.</label>
                      <input type="text" class="form-control" name="godparentPurok[]" placeholder="Enter Purok No." />
                    </div>
                  </div>

                  <!-- Street Address -->
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="godparentStreetAddress">Street Address</label>
                      <input type="text" class="form-control" name="godparentStreetAddress[]" placeholder="Enter Street Address" />
                    </div>
                  </div>

                  <!-- Barangay -->
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="godparentBarangay">Barangay</label>
                      <input type="text" class="form-control" name="godparentBarangay[]" placeholder="Enter Barangay" />
                    </div>
                  </div>

                  <div class="col-md-6">
                      <div class="form-group">
                          <label for="godparentCity">Municipality/City</label>
                          <select class="form-control godparentCity" name="godparentCity[]">
                              <option value="">Select Municipality/City</option>
                          </select>
                      </div>
                  </div>

                  <!-- Province Dropdown -->
                  <div class="col-md-6">
                      <div class="form-group">
                          <label for="godparentProvince">Province</label>
                          <select class="form-control godparentProvince" name="godparentProvince[]">
                              <option value="">Select Province</option>
                          </select>
                      </div>
                  </div>

                  <!-- Remove Button -->
                  <div class="col-md-12">
                    <button type="button" class="btn btn-danger remove-godparent">Remove</button>
                  </div>
                </div>
                <hr />
            `;

            // Add the remove event listener for the new godparent entry
            godparentEntry.querySelector(".remove-godparent").addEventListener("click", function () {
                godparentEntry.remove();
            });

            return godparentEntry;
        }

        // Add the first godparent entry on page load
        addGodparentBtn.addEventListener("click", function () {
            const newGodparentEntry = createGodparentEntry();
            godparentsContainer.appendChild(newGodparentEntry);
            populateProvinces(newGodparentEntry.querySelector('.godparentProvince'));
        });

        // Populate provinces for a given select element
        function populateProvinces(provinceSelector) {
        fetch('https://psgc.gitlab.io/api/provinces/')
            .then(response => response.json())
            .then(data => {
                let provinceOptions = '<option value="">Select Province</option>';
                data.forEach(function (province) {
                    provinceOptions += `<option value="${province.name}">${province.name}</option>`;
                });
                $(provinceSelector).html(provinceOptions);
            });
    }

    // Populate cities based on the selected province
    function populateCities(provinceSelector, citySelector) {
        const selectedProvinceName = $(provinceSelector).val();
        if (selectedProvinceName) {
            // Get the province code based on the selected name
            fetch(`https://psgc.gitlab.io/api/provinces/`)
                .then(response => response.json())
                .then(data => {
                    const province = data.find(p => p.name === selectedProvinceName);
                    if (province) {
                        return fetch(`https://psgc.gitlab.io/api/provinces/${province.code}/cities-municipalities/`);
                    } else {
                        throw new Error('Province not found');
                    }
                })
                .then(response => response.json())
                .then(data => {
                    let cityOptions = '<option value="">Select City/Municipality</option>';
                    data.forEach(function (city) {
                        cityOptions += `<option value="${city.name}">${city.name}</option>`;
                    });
                    $(citySelector).html(cityOptions);
                });
        } else {
            $(citySelector).html('<option value="">Select City/Municipality</option>');
        }
    }

    // Event listener for province selection change
    godparentsContainer.addEventListener("change", function (event) {
        if (event.target.classList.contains('godparentProvince')) {
            const citySelector = $(event.target).closest('.row').find('.godparentCity');
            populateCities(event.target, citySelector);
        }
    });
});
</script>
<script>
    // Function to get the ID from the URL
    function getIdFromUrl() {
        const urlSegments = window.location.pathname.split('/'); // Split the URL by '/'
        const id = urlSegments[urlSegments.length - 1]; // Get the last segment (the ID)
        document.getElementById('baptismId').value = id; // Set the value of the hidden input
    }

    // Call the function when the document is ready
    document.addEventListener('DOMContentLoaded', getIdFromUrl);
</script>
<script>
$(document).ready(function() {
    $('#baptismRecordForm').on('submit', function(e) {
        e.preventDefault(); // Prevent default form submission behavior

        const submitButton = $(this).find('button[type="submit"]');
        submitButton.prop('disabled', true).text('Submitting...');

        $('.form-error').remove(); // Clear previous error messages

        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function(response) {
                console.log(response); // Debugging
                if (response.success) {
                    Swal.fire({
                        title: 'Success!',
                        text: response.message,
                        icon: 'success',
                        confirmButtonText: 'Okay'
                    }).then(() => {
                        location.reload(); // Reload the page after closing the alert
                    });
                } else {
                    Swal.fire({
                        title: 'Error!',
                        text: 'Something went wrong. Please try again.',
                        icon: 'error',
                        confirmButtonText: 'Okay'
                    });
                }
            },
            error: function(xhr) {
                submitButton.prop('disabled', false).text('Submit');

                if (xhr.status === 422) {
                    const errors = xhr.responseJSON.errors;
                    for (const field in errors) {
                        const errorMsg = `<div class="form-error text-danger">${errors[field][0]}</div>`;
                        $(`#${field}`).after(errorMsg); // Display error after the field
                    }
                } else {
                    Swal.fire({
                        title: 'Error!',
                        text: 'An error occurred. Please try again later.',
                        icon: 'error',
                        confirmButtonText: 'Okay'
                    });
                }
            }
        });
    });
});
</script>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Baptism Book No. <?php echo e($bookFolder->book_number); ?> of <?php echo e($baptismYear); ?> Records</h3>
            <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="/">
                <i class="icon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="/baptism">Baptism</a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="/book/<?php echo e($baptismID); ?>">Baptism Book  of <?php echo e($baptismYear); ?> Records</a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="/book_record/<?php echo e($bookFolder->id); ?>">Baptism Book No. <?php echo e($bookFolder->book_number); ?> of <?php echo e($baptismYear); ?> Records</a>
            </li>
            
            
            </ul>
        </div>

       
      <div class="modal fade" id="formModal" tabindex="-1" aria-labelledby="formModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="formModalLabel">Baptism Record Form</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form id="baptismRecordForm" action="<?php echo e(route('baptism.record.store', $baptism_id)); ?>" method="POST">
              <?php echo csrf_field(); ?>
                <div class="container">
                  <div class="page-inner">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="card">
                          <div class="card-body">
                          <input type="hidden" id="baptismId" name="baptism_id" value="<?php echo e($baptism_id); ?>" />
                          <!-- Series/Year No., Book No., Page No., Record Code, and Date of Baptism -->
                          <h5 class="fw-bold mb-3">Baptism Record Details</h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="seriesYearNo">Series/Year No.</label>
                                        <input type="text" class="form-control" id="seriesYearNo" name="seriesYearNo" placeholder="Enter Series/Year No." required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="bookNo">Book No.</label>
                                        <input type="text" class="form-control" id="bookNo" name="bookNo" placeholder="Enter Book No." required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pageNo">Page No.</label>
                                        <input type="text" class="form-control" id="pageNo" name="pageNo" placeholder="Enter Page No." required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="recordCode">Record Code</label>
                                        <input type="text" class="form-control" id="recordCode" name="recordCode" placeholder="Enter Record Code" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="baptismDate">Date of Baptism</label>
                                        <input type="date" class="form-control" id="baptismDate" name="baptismDate" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Child Information -->
                            <h5 class="fw-bold mb-3">Child Information</h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="childFirstName">First Name</label>
                                        <input type="text" class="form-control" id="childFirstName" name="childFirstName" placeholder="Enter First Name"required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="childMiddleName">Middle Name</label>
                                        <input type="text" class="form-control" id="childMiddleName" name="childMiddleName" placeholder="Enter Middle Name" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="childLastName">Last Name</label>
                                        <input type="text" class="form-control" id="childLastName" name="childLastName" placeholder="Enter Last Name" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="childDOB">Date of Birth</label>
                                        <input type="date" class="form-control" id="childDOB" name="childDOB" required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label for="childBirthPlace">Place of Birth:</label>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="childProvince">Child's Province</label>
                                        <select class="form-control" id="childProvince" name="childProvince">
                                            <option value="">Select Province</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="childCity">Child's City/Municipality</label>
                                        <select class="form-control" id="childCity" name="childCity">
                                            <option value="">Select City/Municipality</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Father Information -->
                            <h5 class="fw-bold mb-3">Father's Information</h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fatherFirstName">First Name</label>
                                        <input type="text" class="form-control" id="fatherFirstName" name="fatherFirstName" placeholder="Enter First Name" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fatherMiddleName">Middle Name</label>
                                        <input type="text" class="form-control" id="fatherMiddleName" name="fatherMiddleName" placeholder="Enter Middle Name" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fatherLastName">Last Name</label>
                                        <input type="text" class="form-control" id="fatherLastName" name="fatherLastName" placeholder="Enter Last Name" required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label for="fatherBirthPlace">Place of Birth:</label>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="fatherProvince">Father's Province</label>
                                        <select class="form-control" id="fatherProvince" name="fatherProvince">
                                            <option value="">Select Province</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="fatherCity">Father's City/Municipality</label>
                                        <select class="form-control" id="fatherCity" name="fatherCity">
                                            <option value="">Select City/Municipality</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Mother Information -->
                            <h5 class="fw-bold mb-3">Mother's Information</h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="motherFirstName">First Name</label>
                                        <input type="text" class="form-control" id="motherFirstName" name="motherFirstName" placeholder="Enter First Name" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="motherMiddleName">Middle Name</label>
                                        <input type="text" class="form-control" id="motherMiddleName" name="motherMiddleName" placeholder="Enter Middle Name" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="motherLastName">Last Name</label>
                                        <input type="text" class="form-control" id="motherLastName" name="motherLastName" placeholder="Enter Last Name" required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label for="motherBirthPlace">Place of Birth:</label>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="motherProvince">Mother's Province</label>
                                        <select class="form-control" id="motherProvince" name="motherProvince">
                                            <option value="">Select Province</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="motherCity">Mother's City/Municipality</label>
                                        <select class="form-control" id="motherCity" name="motherCity">
                                            <option value="">Select City/Municipality</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <h5 class="fw-bold mb-3">Residence Address</h5>
                            <div class="row">
                                <!-- Purok No. -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="purokNo">Purok No.</label>
                                        <input type="text" class="form-control" id="purokNo" name="purokNo" placeholder="Enter Purok No." />
                                    </div>
                                </div>

                                <!-- Street Address -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="streetAddress">Street Address</label>
                                        <input type="text" class="form-control" id="streetAddress" name="streetAddress" placeholder="Enter Street Address" />
                                    </div>
                                </div>

                                <!-- Barangay -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="barangay">Barangay</label>
                                        <input type="text" class="form-control" id="barangay" name="barangay" placeholder="Enter Barangay" />
                                    </div>
                                </div>

                                <!-- Province -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="residenceProvince">Province</label>
                                        <select class="form-control" id="residenceProvince" name="residenceProvince">
                                            <option value="">Select Province</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Municipality/City -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="residenceCity">Municipality/City</label>
                                        <select class="form-control" id="residenceCity" name="residenceCity">
                                            <option value="">Select City/Municipality</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Godparent Information (Dynamic Fields) -->
                            <h5 class="fw-bold mb-3">Godparent Information</h5>
                            <div id="godparents-container">
                            
                           
                                
                          
                              

                          </div>
                          <button type="button" id="add-godparent-btn" class="btn btn-primary">Add Godparent</button>
                          <div class="card-action">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <button class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                          </div>
                          
                        </div>

                      </div>
                    </div>
                  </div>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
      </div>
      
    

        <div class="row">
            <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Baptism Book No. <?php echo e($bookFolder->book_number); ?> of <?php echo e($baptismYear); ?> Records</h4>
                                <button
                                class="btn btn-primary btn-round ms-auto"
                                data-bs-toggle="modal" data-bs-target="#formModal"
                                >
                                <i class="fa fa-plus"></i>
                                New Baptism
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                        <!-- Modal -->
                        

                        <div class="table-responsive">
                          <table id="add-row" class="display table table-striped table-hover">
                              <thead>
                                  <tr>
                                      <th style="width: 5%">#</th>
                                      <th style="width: 15%">Record Code</th>
                                      <th style="width: 40%">Name of Child</th>
                                      <th>Date of Baptism</th>
                                      <th style="width: 10%">Action</th>
                                  </tr>
                              </thead>
                              <tfoot>
                                  <tr>
                                      <th style="width: 5%">#</th>
                                      <th>Record Code</th>
                                      <th>Name of Child</th>
                                      <th>Date of Baptism</th>
                                      <th style="width: 10%">Action</th>
                                  </tr>
                              </tfoot>
                              <tbody>
                                  <?php $__currentLoopData = $bookRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                      <td><?php echo e($index + 1); ?></td>
                                      <td><?php echo e($record->record_code); ?></td>
                                      <td><?php echo e($record->child_first_name); ?> <?php echo e($record->child_middle_name); ?> <?php echo e($record->child_last_name); ?></td>
                                      <td><?php echo e(\Carbon\Carbon::parse($record->baptism_date)->format('m/d/Y')); ?></td>
                                      <td>
                                          <div class="form-button-action">
                                          <a href="<?php echo e(route('book.record.info', $record->id)); ?>" type="button" data-bs-toggle="tooltip" title="View Baptism Record" class="btn btn-link btn-primary btn-lg">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                              <button type="button" data-bs-toggle="tooltip" title="Edit Baptism Record"
                                                  class="btn btn-link btn-primary btn-lg"
                                                  onclick="">
                                                  <i class="fa fa-edit"></i>
                                              </button>
                                              <button type="button" data-bs-toggle="tooltip" title="Remove"
                                                  class="btn btn-link btn-danger" onclick="deleteRecord(<?php echo e($record->id); ?>)">
                                                  <i class="fas fa-archive"></i>
                                              </button>
                                          </div>
                                      </td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                          </table>
                      </div>
                        </div>
                    </div>
                </div>
                

                
            </div>
    </div>
</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\ChurchCMS\resources\views/record/book_record.blade.php ENDPATH**/ ?>