<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
    <nav class="pull-left">
        <ul class="nav">
        <li class="nav-item">
          Church Management System
        </li>
        
        </ul>
    </nav>
    
  
    </div>
</footer><?php /**PATH C:\xampp\htdocs\dashboard\ChurchCMS\resources\views/layouts/footer.blade.php ENDPATH**/ ?>