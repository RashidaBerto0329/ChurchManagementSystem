@extends('layouts.header')
@section('content')
<div class="container">
    <div class="page-inner">
    <div
        class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2 pb-4"
    >
        <div>
        <h3 class="fw-bold mb-3">Dashboard</h3>
        
        </div>
        
    </div>
    <div class="row">
        <div class="col-sm-6 col-md-4">
            <div class="card card-stats card-round">
                <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-icon">
                    <div
                        class="icon-big text-center icon-info bubble-shadow-small"
                    >
                        <i class="fas fa-file-archive"></i>
                    </div>
                    </div>
                    <div class="col col-stats ms-3 ms-sm-0">
                    <div class="numbers">
                        <p class="card-category">Church Records</p>
                        <h4 class="card-title">1303</h4>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-4">
            <div class="card card-stats card-round">
                <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-icon">
                    <div
                        class="icon-big text-center icon-primary bubble-shadow-small"
                    >
                        <i class="fas fa-users"></i>
                    </div>
                    </div>
                    <div class="col col-stats ms-3 ms-sm-0">
                    <div class="numbers">
                        <p class="card-category">Members</p>
                        <h4 class="card-title">1,294</h4>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-4">
            <div class="card card-stats card-round">
                <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-icon">
                    <div
                        class="icon-big text-center icon-success bubble-shadow-small"
                    >
                        <i class="fas fa-donate"></i>
                    </div>
                    </div>
                    <div class="col col-stats ms-3 ms-sm-0">
                    <div class="numbers">
                        <p class="card-category">Donations</p>
                        <h4 class="card-title">$ 1,345</h4>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-4">
            <div class="card card-stats card-round">
                <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-icon">
                    <div
                        class="icon-big text-center icon-secondary bubble-shadow-small"
                    >
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    </div>
                    <div class="col col-stats ms-3 ms-sm-0">
                    <div class="numbers">
                        <p class="card-category">Events</p>
                        <h4 class="card-title">576</h4>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-sm-6 col-md-4">
            <div class="card card-stats card-round">
                <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-icon">
                    <div
                        class="icon-big text-center icon-secondary bubble-shadow-small"
                    >
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    </div>
                    <div class="col col-stats ms-3 ms-sm-0">
                    <div class="numbers">
                        <p class="card-category">Schedule</p>
                        <h4 class="card-title">576</h4>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-4">
            <div class="card card-stats card-round">
                <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-icon">
                    <div
                        class="icon-big text-center icon-secondary bubble-shadow-small"
                    >
                        <i class="fas fa-money-bill"></i>
                    </div>
                    </div>
                    <div class="col col-stats ms-3 ms-sm-0">
                    <div class="numbers">
                        <p class="card-category">Payments</p>
                        <h4 class="card-title">576</h4>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    
   
    <div class="row">
       
        <div class="col-md-8">
            <div class="card card-round">
                <div class="card-header">
                <div class="card-head-row card-tools-still-right">
                    <div class="card-title">Transaction History</div>
                    <div class="card-tools">
                    <div class="dropdown">
                        <button
                        class="btn btn-icon btn-clean me-0"
                        type="button"
                        id="dropdownMenuButton"
                        data-bs-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                        >
                        <i class="fas fa-ellipsis-h"></i>
                        </button>
                        <div
                        class="dropdown-menu"
                        aria-labelledby="dropdownMenuButton"
                        >
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <a class="dropdown-item" href="#"
                            >Something else here</a
                        >
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <!-- Projects table -->
                    <table class="table align-items-center mb-0">
                    <thead class="thead-light">
                        <tr>
                        <th scope="col">Payment Number</th>
                        <th scope="col" class="text-end">Date & Time</th>
                        <th scope="col" class="text-end">Amount</th>
                        <th scope="col" class="text-end">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <th scope="row">
                            <button
                            class="btn btn-icon btn-round btn-success btn-sm me-2"
                            >
                            <i class="fa fa-check"></i>
                            </button>
                            Payment from #10231
                        </th>
                        <td class="text-end">Mar 19, 2020, 2.45pm</td>
                        <td class="text-end">$250.00</td>
                        <td class="text-end">
                            <span class="badge badge-success">Completed</span>
                        </td>
                        </tr>
                        <tr>
                        <th scope="row">
                            <button
                            class="btn btn-icon btn-round btn-success btn-sm me-2"
                            >
                            <i class="fa fa-check"></i>
                            </button>
                            Payment from #10231
                        </th>
                        <td class="text-end">Mar 19, 2020, 2.45pm</td>
                        <td class="text-end">$250.00</td>
                        <td class="text-end">
                            <span class="badge badge-success">Completed</span>
                        </td>
                        </tr>
                        <tr>
                        <th scope="row">
                            <button
                            class="btn btn-icon btn-round btn-success btn-sm me-2"
                            >
                            <i class="fa fa-check"></i>
                            </button>
                            Payment from #10231
                        </th>
                        <td class="text-end">Mar 19, 2020, 2.45pm</td>
                        <td class="text-end">$250.00</td>
                        <td class="text-end">
                            <span class="badge badge-success">Completed</span>
                        </td>
                        </tr>
                        <tr>
                        <th scope="row">
                            <button
                            class="btn btn-icon btn-round btn-success btn-sm me-2"
                            >
                            <i class="fa fa-check"></i>
                            </button>
                            Payment from #10231
                        </th>
                        <td class="text-end">Mar 19, 2020, 2.45pm</td>
                        <td class="text-end">$250.00</td>
                        <td class="text-end">
                            <span class="badge badge-success">Completed</span>
                        </td>
                        </tr>
                        <tr>
                        <th scope="row">
                            <button
                            class="btn btn-icon btn-round btn-success btn-sm me-2"
                            >
                            <i class="fa fa-check"></i>
                            </button>
                            Payment from #10231
                        </th>
                        <td class="text-end">Mar 19, 2020, 2.45pm</td>
                        <td class="text-end">$250.00</td>
                        <td class="text-end">
                            <span class="badge badge-success">Completed</span>
                        </td>
                        </tr>
                        <tr>
                        <th scope="row">
                            <button
                            class="btn btn-icon btn-round btn-success btn-sm me-2"
                            >
                            <i class="fa fa-check"></i>
                            </button>
                            Payment from #10231
                        </th>
                        <td class="text-end">Mar 19, 2020, 2.45pm</td>
                        <td class="text-end">$250.00</td>
                        <td class="text-end">
                            <span class="badge badge-success">Completed</span>
                        </td>
                        </tr>
                        <tr>
                        <th scope="row">
                            <button
                            class="btn btn-icon btn-round btn-success btn-sm me-2"
                            >
                            <i class="fa fa-check"></i>
                            </button>
                            Payment from #10231
                        </th>
                        <td class="text-end">Mar 19, 2020, 2.45pm</td>
                        <td class="text-end">$250.00</td>
                        <td class="text-end">
                            <span class="badge badge-success">Completed</span>
                        </td>
                        </tr>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
        </div>
        <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                    <div class="card-title">Monthly Monetary</div>
                    </div>
                    <div class="card-body">
                    <div class="chart-container">
                        <canvas
                        id="pieChart"
                        style="width: 50%; height: 50%"
                        ></canvas>
                    </div>
                    </div>
                </div>
            </div>
        
        
    </div>
    <div class="row">
        <div class="col-md-5">
        <div class="card card-round">
            <div class="card-body">
            <div class="card-head-row card-tools-still-right">
                <div class="card-title">Today</div>
                <div class="card-tools">
                <div class="dropdown">
                    <button
                    class="btn btn-icon btn-clean me-0"
                    type="button"
                    id="dropdownMenuButton"
                    data-bs-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                    >
                    <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div
                    class="dropdown-menu"
                    aria-labelledby="dropdownMenuButton"
                    >
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#"
                        >Something else here</a
                    >
                    </div>
                </div>
                </div>
            </div>
            
            <div class="card-list py-4">
            
            </div>
            </div>
        </div>
        </div>
            
            <div class="col-md-7">
            <div class="card">
                <div class="content w-100">
                <div class="calendar-container">
                    <div class="calendar"> 
                    <div class="year-header"> 
                        <span class="left-button fa fa-chevron-left" id="prev"> </span> 
                        <span class="year" id="label"></span> 
                        <span class="right-button fa fa-chevron-right" id="next"> </span>
                    </div> 
                    <table class="months-table w-100"> 
                        <tbody>
                        <tr class="months-row">
                            <td class="month">Jan</td> 
                            <td class="month">Feb</td> 
                            <td class="month">Mar</td> 
                            <td class="month">Apr</td> 
                            <td class="month">May</td> 
                            <td class="month">Jun</td> 
                            <td class="month">Jul</td>
                            <td class="month">Aug</td> 
                            <td class="month">Sep</td> 
                            <td class="month">Oct</td>          
                            <td class="month">Nov</td>
                            <td class="month">Dec</td>
                        </tr>
                        </tbody>
                    </table> 
                    
                    <table class="days-table w-100"> 
                        <td class="day">Sun</td> 
                        <td class="day">Mon</td> 
                        <td class="day">Tue</td> 
                        <td class="day">Wed</td> 
                        <td class="day">Thu</td> 
                        <td class="day">Fri</td> 
                        <td class="day">Sat</td>
                    </table> 
                    <div class="frame"> 
                        <table class="dates-table w-100"> 
                        <tbody class="tbody">             
                        </tbody> 
                        </table>
                    </div> 
                    <button class="button" id="add-button">Add Event</button>
                    </div>
                </div>
                
                <div class="dialog" id="dialog">
                    <h2 class="dialog-header"> Add New Event </h2>
                    <form class="form" id="form">
                        <div class="form-container" align="center">
                            <label class="form-label" for="occasion">Occasion</label>
                            <input class="input" type="text" id="occasion" maxlength="36">
                            <label class="form-label" for="name">Name</label>
                            <input class="input" type="text" id="name">
                            <input type="button" value="Cancel" class="button" id="cancel-button">
                            <input type="button" value="OK" class="button button-white" id="ok-button">
                        </div>
                    </form>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>



@include('layouts.footer')




@endsection


