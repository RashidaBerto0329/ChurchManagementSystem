
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Confirmation Record of //</h3>
            <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="/">
                <i class="icon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="/confirmation">Confirmation</a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="/confirmation_record">Confirmation Record of //</a>
            </li>
            
            
            
            </ul>
        </div>


        <div class="modal fade" id="formModal" tabindex="-1" aria-labelledby="formModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="formModalLabel">Confirmation Registration Form</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">
          <div class="page-inner">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-body">

                    <!-- Series/Year No., Book No., Page No., Record Code, and Date of Baptism -->
                    <h5 class="fw-bold mb-3">Confirmation</h5>
                    <div class="row">
                      
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="bookName">Book Name</label>
                          <input type="text" class="form-control" id="bookName" placeholder="Enter Book Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="pageNo">Page No.</label>
                          <input type="text" class="form-control" id="pageNo" placeholder="Enter Page No." />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="recordCode">Record Code</label>
                          <input type="text" class="form-control" id="recordCode" placeholder="Enter Record Code" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="ConfirmationDate">Date of Confirmation</label>
                          <input type="date" class="form-control" id="ConfirmationDate" />
                        </div>
                      </div>
                    </div>

                    <!-- Child Information -->
                    <h5 class="fw-bold mb-3">Confirmand's Name</h5>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="childFirstName">First Name</label>
                          <input type="text" class="form-control" id="childFirstName" placeholder="Enter First Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="childMiddleName">Middle Name</label>
                          <input type="text" class="form-control" id="childMiddleName" placeholder="Enter Middle Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="childLastName">Last Name</label>
                          <input type="text" class="form-control" id="childLastName" placeholder="Enter Last Name" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="childDOB">Date of Birth</label>
                          <input type="date" class="form-control" id="childDOB" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="childBirthPlace">Place of Birth</label>
                          <input type="text" class="form-control" id="childBirthPlace" placeholder="Enter Place of Birth" />
                        </div>
                      </div>
                    </div>

                    <!-- Father Information -->
                    <h5 class="fw-bold mb-3">Father's Information</h5>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="fatherFirstName">First Name</label>
                          <input type="text" class="form-control" id="fatherFirstName" placeholder="Enter First Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="fatherMiddleName">Middle Name</label>
                          <input type="text" class="form-control" id="fatherMiddleName" placeholder="Enter Middle Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="fatherLastName">Last Name</label>
                          <input type="text" class="form-control" id="fatherLastName" placeholder="Enter Last Name" />
                        </div>
                      </div>
                      
                    </div>

                    <!-- Mother Information -->
                    <h5 class="fw-bold mb-3">Mother's Information</h5>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="motherFirstName">First Name</label>
                          <input type="text" class="form-control" id="motherFirstName" placeholder="Enter First Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="motherMiddleName">Middle Name</label>
                          <input type="text" class="form-control" id="motherMiddleName" placeholder="Enter Middle Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="motherLastName">Last Name</label>
                          <input type="text" class="form-control" id="motherLastName" placeholder="Enter Last Name" />
                        </div>
                      </div>
                      
                    </div>
                    <h5 class="fw-bold mb-3">Name of Sponsor</h5>
                        <div class="row" id="godparent-rows">
                            <div class="col-md-4">
                                <div class="form-group">
                                <label for="godparentFirstName">First Name</label>
                                <input type="text" class="form-control" id="godparentFirstName" placeholder="Enter First Name" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                <label for="godparentMiddleName">Middle Name</label>
                                <input type="text" class="form-control" id="godparentMiddleName" placeholder="Enter Middle Name" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                <label for="godparentLastName">Last Name</label>
                                <input type="text" class="form-control" id="godparentLastName" placeholder="Enter Last Name" />
                                </div>
                            </div>
                        </div>
                        

                  </div>
                  <div class="card-action">
                    <button class="btn btn-primary">Submit</button>
                    <button class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

        <div class="row">
            <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Confirmation</h4>
                                <button
                                class="btn btn-primary btn-round ms-auto"
                                data-bs-toggle="modal" data-bs-target="#formModal"
                                >
                                <i class="fa fa-plus"></i>
                                New Confirmation
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                        <!-- Modal -->
                     

                        <div class="table-responsive">
                          <table id="add-row" class="display table table-striped table-hover">
                              <thead>
                                  <tr>
                                      <th style="width: 5%">#</th>
                                      <th style="width: 15%">Record Code</th>
                                      <th style="width: 40%">Name of Confirmands</th>
                                      <th>Date of Confirmation</th>
                                      <th style="width: 10%">Action</th>
                                  </tr>
                              </thead>
                              <tfoot>
                                  <tr>
                                      <th style="width: 5%">#</th>
                                      <th style="width: 15%">Record Code</th>
                                      <th style="width: 40%">Name of Confirmands</th>
                                      <th>Date of Confirmation</th>
                                      <th style="width: 10%">Action</th>
                                  </tr>
                              </tfoot>
                              <tbody>
                                  
                                  <tr>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td>
                                          <div class="form-button-action">
                                          <a href="" type="button" data-bs-toggle="tooltip" title="View Baptism Record" class="btn btn-link btn-primary btn-lg">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                              <button type="button" data-bs-toggle="tooltip" title="Edit Baptism Record"
                                                  class="btn btn-link btn-primary btn-lg"
                                                  onclick="">
                                                  <i class="fa fa-edit"></i>
                                              </button>
                                              <button type="button" data-bs-toggle="tooltip" title="Remove"
                                                  class="btn btn-link btn-danger" onclick="">
                                                  <i class="fas fa-archive"></i>
                                              </button>
                                          </div>
                                      </td>
                                  </tr>
                                 
                              </tbody>
                          </table>
                      </div>
                        </div>
                    </div>
                </div>
                

                
            </div>
    </div>
</div>



<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\ChurchCMS\resources\views/record/confirmation_record.blade.php ENDPATH**/ ?>