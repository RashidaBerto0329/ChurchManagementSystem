<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Baptism_folder;
use App\Models\BookFolder;

class BaptismFolderController extends Controller
{
    // Method to add a new year
    public function addYear(Request $request)
    {
        $request->validate([
            'year' => 'required|integer|min:1000|max:3000'
        ]);

        $year = new Baptism_folder();
        $year->year = $request->input('year');
        $year->save();

        return response()->json([
            'success' => true,
            'message' => 'Year added successfully!'
        ]);
    }

    public function index()
    {
        // Fetch all baptism records
        $years = Baptism_folder::all();
    
        // Initialize an array to hold baptism records with book counts
        $baptismWithBookCounts = $years->map(function($baptism) {
            // Get the count of book records where baptism_id matches
            $bookCount = BookFolder::where('baptism_id', $baptism->id)->count();
            return [
                'id' => $baptism->id, // Include the id
                'year' => $baptism->year,
                'book_count' => $bookCount
            ];
        });
    
        return view('record/baptism', ['baptisms' => $baptismWithBookCounts]);
    }


}