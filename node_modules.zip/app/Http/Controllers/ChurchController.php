<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ChurchController extends Controller
{
    public function index(){
        return view('index');
    }
    public function baptism() {
        return view('record/baptism');
    }
    public function book() {
        return view('record/book');
    }
 
    public function confirmation() {
        return view('record/confirmation');
    }
    public function confirmation_record() {
        return view('record/confirmation_record');
    }
    public function wedding() {
        return view('record/wedding');
    }
    public function wedding_record() {
        return view('record/wedding_record');
    }
    public function funeral() {
        return view('record/funeral');
    }
    public function funeral_record() {
        return view('record/funeral_record');
    }
    
    public function member()  {
        return view('members/member');
    }
    public function volunteer()  {
        return view('members/volunteer');
    }
    public function collection()  {
        return view('finances/collection');
    }
    public function donation()  {
        return view('finances/donation');
    }
    public function payment()  {
        return view('finances/payment');
    }
    public function calendar() {
        return view('calendars/calendar');
    }
    public function archives()  {
        return view('archives/archives');
    }
    
       
}
