
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Baptism</h3>
            <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="/">
                <i class="icon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="/baptism">Baptism</a>
            </li>
            
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Series</h4>
                                <button
                                class="btn btn-primary btn-round ms-auto"
                                data-bs-toggle="modal"
                                data-bs-target="#addRowModal"
                                >
                                <i class="fa fa-plus"></i>
                                Add New Series
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                        <!-- Modal -->
                        <div
                            class="modal fade"
                            id="addRowModal"
                            tabindex="-1"
                            role="dialog"
                            aria-hidden="true"
                        >
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header border-0">
                                <h5 class="modal-title">
                                    <span class="fw-mediumbold"> New</span>
                                    <span class="fw-light"> Series </span>
                                </h5>
                                <button
                                    type="button"
                                    class="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                <p class="small">
                                    Create New Series
                                </p>
                                <form>
                                    <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group form-group-default">
                                        <label>Year</label>
                                        <input
                                            id="addName"
                                            type="number"
                                            class="form-control"
                                            placeholder="Series Year"
                                            min ='0'
                                            
                                        />
                                        </div>
                                    </div>
                                    
                                    </div>
                                </form>
                                </div>
                                <div class="modal-footer border-0">
                                <button
                                    type="button"
                                    id="addRowButton"
                                    class="btn btn-primary"
                                >
                                    Add
                                </button>
                                <button
                                    type="button"
                                    class="btn btn-danger"
                                    data-dismiss="modal"
                                >
                                    Close
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>

                        <div class="table-responsive ">
                            <table
                            id="add-row"
                            class="display table table-striped table-hover"
                       
                            >
                            <thead>
                                <tr>
                                <th style="width: 10%"> Year</th>
                                <th style="width: 45%">No. Books</th>
                                
                                <th style="width: 20%">Action</th>
                                </tr>
                            </thead>
                            
                            <tbody>
                                <?php $__currentLoopData = $baptisms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baptism): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><i class="fas fa-book"> - </i> <?php echo e($baptism['year']); ?></td>
                                        <td><?php echo e($baptism['book_count']); ?> Total Books</td>
                                        <td>
                                            <div class="form-button-action">
                                                <button
                                                    type="button"
                                                    data-bs-toggle="tooltip"
                                                    title="Edit Task"
                                                    class="btn btn-link btn-primary btn-lg"
                                                    data-original-title="Edit Task"
                                                    onclick="window.location.href='/book/<?php echo e($baptism['id']); ?>'"
                                                >
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                                <button
                                                    type="button"
                                                    data-bs-toggle="tooltip"
                                                    title="Remove"
                                                    class="btn btn-link btn-danger"
                                                    data-original-title="Remove"
                                                    
                                                >
                                                    <i class="fas fa-archive"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                        </div>
                        </div>
                    </div>
                </div>
                

                
            </div>
    </div>
    
</div>
<script>
      document.getElementById('addRowButton').addEventListener('click', function() {
    const year = document.getElementById('addName').value;
    
    fetch("<?php echo e(route('add.year')); ?>", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: JSON.stringify({ year: year })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                title: 'Success!',
                text: data.message,
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(() => {
                // Redirect to /baptism
                window.location.href = '/baptism';
            });
        } else {
            Swal.fire({
                title: 'Error!',
                text: 'Failed to add year.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        }
    });
});
</script>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\ChurchCMS\resources\views/record/baptism.blade.php ENDPATH**/ ?>