@extends('layouts.header')
@section('content')
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Confirmation</h3>
            <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="/">
                <i class="icon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="/confirmation">Confirmation</a>
            </li>
            
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Confirmation</h4>
                                <button
                                class="btn btn-primary btn-round ms-auto"
                                data-bs-toggle="modal"
                                data-bs-target="#addRowModal"
                                >
                                <i class="fa fa-plus"></i>
                                Add New Folder
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                        <!-- Modal -->
                        <div
                            class="modal fade"
                            id="addRowModal"
                            tabindex="-1"
                            role="dialog"
                            aria-hidden="true"
                        >
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header border-0">
                                <h5 class="modal-title">
                                    <span class="fw-mediumbold"> New</span>
                                    <span class="fw-light"> Series </span>
                                </h5>
                                <button
                                    type="button"
                                    class="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                <p class="small">
                                    Create New Series
                                </p>
                                <form>
                                    <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group form-group-default">
                                        <label>Year</label>
                                        <input
                                            id="addName"
                                            type="number"
                                            class="form-control"
                                            placeholder="Series Year"
                                            min ='0'
                                            
                                        />
                                        </div>
                                    </div>
                                    
                                    </div>
                                </form>
                                </div>
                                <div class="modal-footer border-0">
                                <button
                                    type="button"
                                    id="addRowButton"
                                    class="btn btn-primary"
                                >
                                    Add
                                </button>
                                <button
                                    type="button"
                                    class="btn btn-danger"
                                    data-dismiss="modal"
                                >
                                    Close
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table
                            id="add-row"
                            class="display table table-striped table-hover"
                       
                            >
                            <thead>
                                <tr>
                                <th> Year</th>
                                <th>No. Confirmed Record</th>
                                
                                <th style="width: 10%">Action</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                <th> Year</th>
                                <th>No. Confirmed Record</th>
                                
                                <th style="width: 10%">Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <tr>
                                <td><i class="fas fa-book"> - </i> 2012</td>
                                <td>40 Confirmed Record</td>
                                <td>
                                    <div class="form-button-action">
                                    <button
                                        type="button"
                                        data-bs-toggle="tooltip"
                                        title=""
                                        class="btn btn-link btn-primary btn-lg"
                                        data-original-title="Edit Task"
                                        onclick="window.location.href='/confirmation_record'"
                                    >
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <button
                                        type="button"
                                        data-bs-toggle="tooltip"
                                        title=""
                                        class="btn btn-link btn-danger"
                                        data-original-title="Remove"
                                    >
                                        <i class="fas fa-archive"></i>
                                    </button>
                                    

                                    </div>
                                </td>
                                </tr>
                                
                            </tbody>
                            </table>
                        </div>
                        </div>
                    </div>
                </div>
               

                
            </div>
    </div>
</div>



@include('layouts.footer')




@endsection


