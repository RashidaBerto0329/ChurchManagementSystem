
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Baptised Information</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="/">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="/baptism">Baptism</a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="/book/<?php echo e($baptismID); ?>">Baptism Book of <?php echo e($baptismYear); ?> Records</a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="/book_record/<?php echo e($bookFolder->id); ?>">Baptism Book No. <?php echo e($bookFolder->book_number); ?> of <?php echo e($baptismYear); ?> Records</a>
                </li>
            </ul>
        </div>

        <!-- Baptism Record Information -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Baptism Record Details</h5>
                
                <div class="table-responsive"><!-- Book and Record Info -->
                    <table class="display table table-striped table-hover">
                        <thead>
                            <tr>
                                <th colspan = '2'>Book No: <?php echo e($bookRecord->book_no); ?>/Page No: <?php echo e($bookRecord->page_no); ?>/Record Code: <?php echo e($bookRecord->record_code); ?>/Series Year No: <?php echo e($bookRecord->series_year_no); ?> </th>
                                
                            </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td style="width: 15%"><strong>Name:</strong></td>
                            <td><?php echo e($bookRecord->child_first_name); ?> <?php echo e($bookRecord->child_middle_name); ?> <?php echo e($bookRecord->child_last_name); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 15%"><strong>Date of Birth:</strong></td>
                            <td><?php echo e($bookRecord->child_dob); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 15%"><strong>Place of Birth:</strong></td>
                            <td><?php echo e($bookRecord->child_city); ?>, <?php echo e($bookRecord->child_province); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 15%"><strong>Father's Name:</strong></td>
                            <td><?php echo e($bookRecord->father_first_name); ?> <?php echo e($bookRecord->father_middle_name); ?> <?php echo e($bookRecord->father_last_name); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 15%"><strong>Place of Birth:</strong></td>
                            <td><?php echo e($bookRecord->father_city); ?>, <?php echo e($bookRecord->father_province); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 15%"><strong>Mother's Name:</strong></td>
                            <td><?php echo e($bookRecord->mother_first_name); ?> <?php echo e($bookRecord->mother_middle_name); ?> <?php echo e($bookRecord->mother_last_name); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 15%"><strong>Place of Birth:</strong></td>
                            <td><?php echo e($bookRecord->mother_city); ?>, <?php echo e($bookRecord->mother_province); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 15%"><strong>Residence:</strong></td>
                            <td><?php echo e($bookRecord->residence_city); ?>, <?php echo e($bookRecord->residence_province); ?></td>
                        </tr>
                        
                        <tr>
                            <td colspan = '2'><strong>Sponsors</strong></td>
                            
                        </tr>

                        <?php $__currentLoopData = $godparents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $godparent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="width: 15%"><strong>Sponsor's Name:</strong></td>
                                <td> <?php echo e($godparent->first_name); ?> <?php echo e($godparent->middle_name); ?> <?php echo e($godparent->last_name); ?></td>
                            </tr>
                            <tr>
                                <td style="width: 15%"><strong>Address:</strong></td>
                                <td><?php echo e($godparent->municipality_city); ?>, <?php echo e($godparent->province); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 15%"></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="width: 15%"><strong>Priest/Minister</strong></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="width: 15%"><strong>Date of Baptism</strong></td>
                            <td><?php echo e($bookRecord->baptism_date); ?></td>
                        </tr>
                            
                        </tbody>
                    </table>
                </div>
           
                
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\ChurchCMS\resources\views/record/book_record_info.blade.php ENDPATH**/ ?>