
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Collection</h3>
            <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="/">
                <i class="icon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="/collection">Collection</a>
            </li>
          
            
            
            
            </ul>
        </div>

        <div class="modal fade" id="formModal" tabindex="-1" aria-labelledby="formModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="formModalLabel">Collection Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">
          <div class="page-inner">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-body">

                    <!-- Acolytes Information -->
                    <h5 class="fw-bold mb-3">Acolytes Information</h5>
                    <div id="acolytesContainer">
                      <!-- Default Acolyte -->
                      <div class="acolyte-group">
                        <div class="row">
                          <div class="col-md-4">
                            <div class="form-group">
                              <label for="acolyteFirstName">First Name</label>
                              <input type="text" class="form-control" name="acolyteFirstName[]" placeholder="Enter First Name" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label for="acolyteMiddleName">Middle Name</label>
                              <input type="text" class="form-control" name="acolyteMiddleName[]" placeholder="Enter Middle Name" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label for="acolyteLastName">Last Name</label>
                              <input type="text" class="form-control" name="acolyteLastName[]" placeholder="Enter Last Name" />
                            </div>
                          </div>
                        </div>
                        <hr />
                      </div>
                    </div>
                    <button type="button" class="btn btn-secondary" onclick="addAcolyte()">Add Another Acolyte</button>

                    <!-- Date and Time Schedule -->
                    <h5 class="fw-bold mb-3 mt-4">Date and Time Schedule</h5>
                    <div class="row">
                      <div class="col-md-7">
                        <div class="form-group">
                          <label for="collectionDate">Date</label>
                          <input type="date" class="form-control" id="collectionDate" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="startTime">Start Time</label>
                          <input type="time" class="form-control" id="startTime" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="endTime">End Time</label>
                          <input type="time" class="form-control" id="endTime" />
                        </div>
                      </div>
                    </div>

                    <!-- In-Kind Collection -->
                    <h5 class="fw-bold mb-3 mt-4">In-Kind Collection</h5>
                    <div id="inkindCollectionContainer">
                      <!-- Default In-Kind Collection -->
                      <div class="inkind-collection-group">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="inkindItems">Items</label>
                              <input type="text" class="form-control" name="inkindItems[]" placeholder="Enter Items" />
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="inkindPieces">Pieces</label>
                              <input type="number" class="form-control" name="inkindPieces[]" placeholder="Enter Pieces" />
                            </div>
                          </div>
                        </div>
                        <hr />
                      </div>
                    </div>
                    <button type="button" class="btn btn-secondary" onclick="addInKindCollection()">Add Another In-Kind Collection</button>

                    <!-- Money Collection -->
                    <h5 class="fw-bold mb-3 mt-4">Money Collection</h5>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="moneyAmount">Amount</label>
                          <input type="number" class="form-control" id="moneyAmount" placeholder="Enter Amount" />
                        </div>
                      </div>
                    </div>

                  </div>
                  <div class="card-action">
                    <button class="btn btn-primary">Submit</button>
                    <button class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  function addAcolyte() {
    const acolytesContainer = document.getElementById('acolytesContainer');
    const acolyteGroup = document.createElement('div');
    acolyteGroup.className = 'acolyte-group';
    acolyteGroup.innerHTML = `
      <div class="row">
        <div class="col-md-4">
          <div class="form-group">
            <label for="acolyteFirstName">First Name</label>
            <input type="text" class="form-control" name="acolyteFirstName[]" placeholder="Enter First Name" />
          </div>
        </div>
        <div class="col-md-4">
          <div class="form-group">
            <label for="acolyteMiddleName">Middle Name</label>
            <input type="text" class="form-control" name="acolyteMiddleName[]" placeholder="Enter Middle Name" />
          </div>
        </div>
        <div class="col-md-4">
          <div class="form-group">
            <label for="acolyteLastName">Last Name</label>
            <input type="text" class="form-control" name="acolyteLastName[]" placeholder="Enter Last Name" />
          </div>
        </div>
      </div>
      <hr />
    `;
    acolytesContainer.appendChild(acolyteGroup);
  }

  function addInKindCollection() {
    const inkindCollectionContainer = document.getElementById('inkindCollectionContainer');
    const inkindCollectionGroup = document.createElement('div');
    inkindCollectionGroup.className = 'inkind-collection-group';
    inkindCollectionGroup.innerHTML = `
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label for="inkindItems">Items</label>
            <input type="text" class="form-control" name="inkindItems[]" placeholder="Enter Items" />
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="inkindPieces">Pieces</label>
            <input type="number" class="form-control" name="inkindPieces[]" placeholder="Enter Pieces" />
          </div>
        </div>
      </div>
      <hr />
    `;
    inkindCollectionContainer.appendChild(inkindCollectionGroup);
  }

</script>



        <div class="row">
            <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Collection</h4>
                                <button
                                class="btn btn-primary btn-round ms-auto"
                                data-bs-toggle="modal" data-bs-target="#formModal"
                                >
                                <i class="fa fa-plus"></i>
                                Collection record
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                        <!-- Modal -->
                        <div
                            class="modal fade"
                            id="addRowModal"
                            tabindex="-1"
                            role="dialog"
                            aria-hidden="true"
                        >
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header border-0">
                                <h5 class="modal-title">
                                    <span class="fw-mediumbold"> New</span>
                                    <span class="fw-light"> Series </span>
                                </h5>
                                <button
                                    type="button"
                                    class="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                <p class="small">
                                    Create New Series
                                </p>
                                <form>
                                    <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group form-group-default">
                                        <label>Year</label>
                                        <input
                                            id="addName"
                                            type="number"
                                            class="form-control"
                                            placeholder="Series Year"
                                            min ='0'
                                            
                                        />
                                        </div>
                                    </div>
                                    
                                    </div>
                                </form>
                                </div>
                                <div class="modal-footer border-0">
                                <button
                                    type="button"
                                    id="addRowButton"
                                    class="btn btn-primary"
                                >
                                    Add
                                </button>
                                <button
                                    type="button"
                                    class="btn btn-danger"
                                    data-dismiss="modal"
                                >
                                    Close
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                          <table id="add-row" class="display table table-striped table-hover">
                              <thead>
                                  <tr>
                                      <th style="width: 5%">#</th>
                                      <th style="width: 15%">Acolyte's Name</th>
                                      <th style="width: 40%">Collected On</th>
                                      <th>Time</th>
                                      <th style="width: 10%">Action</th>
                                  </tr>
                              </thead>
                              <tfoot>
                              <tr>
                                      <th style="width: 5%">#</th>
                                      <th style="width: 15%">Acolyte's Name</th>
                                      <th style="width: 40%">Collected On</th>
                                      <th>Time</th>
                                      <th style="width: 10%">Action</th>
                                  </tr>
                              </tfoot>
                              <tbody>
                                  
                                  <tr>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td>
                                          <div class="form-button-action">
                                          <a href="" type="button" data-bs-toggle="tooltip" title="View Baptism Record" class="btn btn-link btn-primary btn-lg">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                              <button type="button" data-bs-toggle="tooltip" title="Edit Baptism Record"
                                                  class="btn btn-link btn-primary btn-lg"
                                                  onclick="">
                                                  <i class="fa fa-edit"></i>
                                              </button>
                                              <button type="button" data-bs-toggle="tooltip" title="Remove"
                                                  class="btn btn-link btn-danger" onclick="">
                                                  <i class="fas fa-archive"></i>
                                              </button>
                                          </div>
                                      </td>
                                  </tr>
                                 
                              </tbody>
                          </table>
                      </div>
                        </div>
                    </div>
                </div>
                

                
            </div>
    </div>
</div>



<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\ChurchCMS\resources\views/finances/collection.blade.php ENDPATH**/ ?>