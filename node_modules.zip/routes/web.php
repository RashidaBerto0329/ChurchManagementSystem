<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ChurchController;
use App\Http\Controllers\EventController;
use App\Models\Event;
use App\Models\Baptism_folder;
use App\Models\Book_folder;
use App\Http\Controllers\BaptismFolderController;
use App\Http\Controllers\BookFolderController;
use App\Http\Controllers\BookRecordController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\VolunteerController;

Route::get('/','App\Http\Controllers\ChurchController@index')->middleware('auth');
Route::get('/baptism', [BaptismFolderController::class, 'index'])->name('baptism.index')->middleware('auth');
Route::get('/book/{baptism_id}', [BookFolderController::class, 'showByBaptism'])->name('book.showByBaptism')->middleware('auth');
Route::post('/book/store', [BookFolderController::class, 'store'])->name('book.store')->middleware('auth');
Route::get('/book_record/{baptism_id}', [BookRecordController::class, 'showByBaptism'])->name('book_record.showByBaptism')->middleware('auth');
Route::get('/delete_record/{id}', [BookRecordController::class, 'destroy'])->name('book_record.destroy')->middleware('auth');
Route::get('/confirmation','App\Http\Controllers\ChurchController@confirmation')->middleware('auth');
Route::get('/confirmation_record','App\Http\Controllers\ChurchController@confirmation_record')->middleware('auth');
Route::get('/wedding', 'App\Http\Controllers\ChurchController@wedding')->middleware('auth');
Route::get('/wedding_record', 'App\Http\Controllers\ChurchController@wedding_record')->middleware('auth');
Route::get('/funeral', 'App\Http\Controllers\ChurchController@funeral')->middleware('auth');
Route::get('/funeral_record', 'App\Http\Controllers\ChurchController@funeral_record')->middleware('auth');

Route::get('/member', [MemberController::class, 'index'])->name('members.index')->middleware('auth');
Route::post('/member', [MemberController::class, 'store'])->name('member.store');
Route::resource('members', MemberController::class)->middleware('auth');
Route::put('/members/{member}', [MemberController::class, 'update'])->name('members.update');

Route::get('/volunteer', [VolunteerController::class, 'index'])->name('volunteers.index')->middleware('auth');
Route::post('/volunteer', [VolunteerController::class, 'store'])->name('volunteer.store');
Route::resource('volunteers', VolunteerController::class)->middleware('auth');
Route::put('/volunteers/{volunteer}', [VolunteerController::class, 'update'])->name('volunteers.update');

Route::get('/collection','App\Http\Controllers\ChurchController@collection')->middleware('auth');
Route::get('/donation', 'App\Http\Controllers\ChurchController@donation')->middleware('auth');
Route::get('/payment','App\Http\Controllers\ChurchController@payment')->middleware('auth');
Route::get('/calendars','App\Http\Controllers\ChurchController@calendar' )->middleware('auth');
Route::get('/archive', 'App\Http\Controllers\ChurchController@archives')->middleware('auth');
Route::post('/add-year', [BaptismFolderController::class, 'addYear'])->name('add.year');


Route::post('/book_record/{baptism_id}', [BookRecordController::class, 'store'])->name('baptism.record.store')->middleware('auth');
Route::get('/book-record/{id}', [BookRecordController::class, 'showInfo'])->name('book.record.info')->middleware('auth');



Route::post('/', 'App\Http\Controllers\EventController@store');

Route::get('/get-events', function() {
    $events = Event::all(); 
    return response()->json($events);
});




Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
