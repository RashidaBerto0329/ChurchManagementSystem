<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
    <nav class="pull-left">
        <ul class="nav">
        <li class="nav-item">
          Church Management System
        </li>
        
        </ul>
    </nav>
    
  
    </div>
</footer>