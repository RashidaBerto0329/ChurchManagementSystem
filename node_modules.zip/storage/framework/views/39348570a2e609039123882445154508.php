
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Wedding Record of //</h3>
            <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="/">
                <i class="icon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="/wedding">Wedding</a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="/wedding_record">Wedding Record of //</a>
            </li>
            
            
            
            </ul>
        </div>


        <div class="modal fade" id="formModal" tabindex="-1" aria-labelledby="formModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="formModalLabel">Wedding Registration Form</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">
          <div class="page-inner">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-body">
                    <h5 class="fw-bold mb-3">Wedding Registration Form</h5>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="recordCode">Record Code</label>
                          <input type="text" class="form-control" id="recordCode" placeholder="Enter Record Code" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="weddingDate">Date of Wedding</label>
                          <input type="date" class="form-control" id="weddingDate" />
                        </div>
                      </div>
                    </div>

                    <!-- Groom Information -->
                    <h5 class="fw-bold mb-3">Groom's Information</h5>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="groomFirstName">First Name</label>
                          <input type="text" class="form-control" id="groomFirstName" placeholder="Enter First Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="groomMiddleName">Middle Name</label>
                          <input type="text" class="form-control" id="groomMiddleName" placeholder="Enter Middle Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="groomLastName">Last Name</label>
                          <input type="text" class="form-control" id="groomLastName" placeholder="Enter Last Name" />
                        </div>
                      </div>
                    </div>

                    <!-- Groom's Birth Information -->
                    <h5 class="fw-bold mb-3">Groom's Birth Information</h5>
                    <div class="row">
                      <div class="col-md-7">
                        <div class="form-group">
                          <label for="groomBirthDate">Birth Date</label>
                          <input type="date" class="form-control" id="groomBirthDate" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="groomBirthMunicipality">Place of Birth - Municipality</label>
                          <input type="text" class="form-control" id="groomBirthMunicipality" placeholder="Enter Municipality" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="groomBirthProvince">Place of Birth - Province</label>
                          <input type="text" class="form-control" id="groomBirthProvince" placeholder="Enter Province" />
                        </div>
                      </div>
                    </div>

                    <h5 class="fw-bold mb-3">Groom's Residence Address</h5>
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group">
                          <label for="groomPurokNo">Purok No.</label>
                          <input type="text" class="form-control" id="groomPurokNo" placeholder="Enter Purok No." />
                        </div>
                      </div>
                      <div class="col-md-5">
                        <div class="form-group">
                          <label for="groomStreetAddress">Street Address</label>
                          <input type="text" class="form-control" id="groomStreetAddress" placeholder="Enter Street Address" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="groomBarangay">Barangay</label>
                          <input type="text" class="form-control" id="groomBarangay" placeholder="Enter Barangay" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="groomMunicipality">Municipality</label>
                          <input type="text" class="form-control" id="groomMunicipality" placeholder="Enter Municipality" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="groomProvince">Province</label>
                          <input type="text" class="form-control" id="groomProvince" placeholder="Enter Province" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="groomContactNo">Contact No.</label>
                          <input type="text" class="form-control" id="groomContactNo" placeholder="Enter Contact No." />
                        </div>
                      </div>
                    </div>

                    <!-- Bride Information -->
                    <h5 class="fw-bold mb-3">Bride's Information</h5>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="brideFirstName">First Name</label>
                          <input type="text" class="form-control" id="brideFirstName" placeholder="Enter First Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="brideMiddleName">Middle Name</label>
                          <input type="text" class="form-control" id="brideMiddleName" placeholder="Enter Middle Name" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="brideLastName">Last Name</label>
                          <input type="text" class="form-control" id="brideLastName" placeholder="Enter Last Name" />
                        </div>
                      </div>
                    </div>

                    <!-- Bride's Birth Information -->
                    <h5 class="fw-bold mb-3">Bride's Birth Information</h5>
                    <div class="row">
                      <div class="col-md-7">
                        <div class="form-group">
                          <label for="brideBirthDate">Birth Date</label>
                          <input type="date" class="form-control" id="brideBirthDate" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="brideBirthMunicipality">Place of Birth - Municipality</label>
                          <input type="text" class="form-control" id="brideBirthMunicipality" placeholder="Enter Municipality" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="brideBirthProvince">Place of Birth - Province</label>
                          <input type="text" class="form-control" id="brideBirthProvince" placeholder="Enter Province" />
                        </div>
                      </div>
                    </div>

                    <h5 class="fw-bold mb-3">Bride's Residence Address</h5>
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group">
                          <label for="bridePurokNo">Purok No.</label>
                          <input type="text" class="form-control" id="bridePurokNo" placeholder="Enter Purok No." />
                        </div>
                      </div>
                      <div class="col-md-5">
                        <div class="form-group">
                          <label for="brideStreetAddress">Street Address</label>
                          <input type="text" class="form-control" id="brideStreetAddress" placeholder="Enter Street Address" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="brideBarangay">Barangay</label>
                          <input type="text" class="form-control" id="brideBarangay" placeholder="Enter Barangay" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="brideMunicipality">Municipality</label>
                          <input type="text" class="form-control" id="brideMunicipality" placeholder="Enter Municipality" />
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="brideProvince">Province</label>
                          <input type="text" class="form-control" id="brideProvince" placeholder="Enter Province" />
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="brideContactNo">Contact No.</label>
                          <input type="text" class="form-control" id="brideContactNo" placeholder="Enter Contact No." />
                        </div>
                      </div>
                    </div>
                    <h5 class="fw-bold mb-3">Documents Presented</h5>
                    <div class="form-group mt-3">
                    <label for="PresentedFile">Documents Presented</label>
                    <input type="file" class="form-control" id="PresentedFile" />
                    </div>

                  </div>
                  <div class="card-action">
                    <button class="btn btn-primary">Submit</button>
                    <button class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


        <div class="row">
            <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Confirmation</h4>
                                <button
                                class="btn btn-primary btn-round ms-auto"
                                data-bs-toggle="modal" data-bs-target="#formModal"
                                >
                                <i class="fa fa-plus"></i>
                                New Confirmation
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                        <!-- Modal -->
                        <div
                            class="modal fade"
                            id="addRowModal"
                            tabindex="-1"
                            role="dialog"
                            aria-hidden="true"
                        >
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header border-0">
                                <h5 class="modal-title">
                                    <span class="fw-mediumbold"> New</span>
                                    <span class="fw-light"> Series </span>
                                </h5>
                                <button
                                    type="button"
                                    class="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                >
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                <p class="small">
                                    Create New Series
                                </p>
                                <form>
                                    <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group form-group-default">
                                        <label>Year</label>
                                        <input
                                            id="addName"
                                            type="number"
                                            class="form-control"
                                            placeholder="Series Year"
                                            min ='0'
                                            
                                        />
                                        </div>
                                    </div>
                                    
                                    </div>
                                </form>
                                </div>
                                <div class="modal-footer border-0">
                                <button
                                    type="button"
                                    id="addRowButton"
                                    class="btn btn-primary"
                                >
                                    Add
                                </button>
                                <button
                                    type="button"
                                    class="btn btn-danger"
                                    data-dismiss="modal"
                                >
                                    Close
                                </button>
                                </div>
                            </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                          <table id="add-row" class="display table table-striped table-hover">
                              <thead>
                                  <tr>
                                      <th style="width: 5%">#</th>
                                      <th style="width: 15%">Record Code</th>
                                      <th style="width: 40%">Name of Couple</th>
                                      <th>Date of Wedding</th>
                                      <th style="width: 10%">Action</th>
                                  </tr>
                              </thead>
                              <tfoot>
                                  <tr>
                                      <th style="width: 5%">#</th>
                                      <th style="width: 15%">Record Code</th>
                                      <th style="width: 40%">Name of Couple</th>
                                      <th>Date of Wedding</th>
                                      <th style="width: 10%">Action</th>
                                  </tr>
                              </tfoot>
                              <tbody>
                                  
                                  <tr>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                      <td>
                                          <div class="form-button-action">
                                          <a href="" type="button" data-bs-toggle="tooltip" title="View Baptism Record" class="btn btn-link btn-primary btn-lg">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                              <button type="button" data-bs-toggle="tooltip" title="Edit Baptism Record"
                                                  class="btn btn-link btn-primary btn-lg"
                                                  onclick="">
                                                  <i class="fa fa-edit"></i>
                                              </button>
                                              <button type="button" data-bs-toggle="tooltip" title="Remove"
                                                  class="btn btn-link btn-danger" onclick="">
                                                  <i class="fas fa-archive"></i>
                                              </button>
                                          </div>
                                      </td>
                                  </tr>
                                 
                              </tbody>
                          </table>
                      </div>
                        </div>
                    </div>
                </div>
                

                
            </div>
    </div>
</div>



<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\ChurchCMS\resources\views/record/wedding_record.blade.php ENDPATH**/ ?>